-- Safety helpers (anti-AFK, idle randomization)
local S = {}

function S.Tick()
    -- anti afk logic here
end

return S
