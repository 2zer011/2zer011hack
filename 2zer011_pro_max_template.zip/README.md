# 2zer011 auto bounty blox fruit vip (TEMPLATE)
Educational / learning template only.

This package contains a SAFE architecture skeleton (no bypass, no auto-abuse).
Use for studying GUI, HUD, AI decision flow, and modular Lua structure.

