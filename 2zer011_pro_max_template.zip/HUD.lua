-- HUD display skeleton
local HUD = {}

function HUD.Update(info)
    -- info.hp, info.level, info.dist, info.dps
end

return HUD
