-- Target selection logic (template)
local T = {}

function T.Select(players, Config)
    -- scoring logic here
    return nil
end

return T
