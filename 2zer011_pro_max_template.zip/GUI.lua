-- Paid-style GUI skeleton
local GUI = {}

function GUI.Init(Config)
    print("GUI Loaded | 2zer011 PRO MAX")
    -- build toggles, sliders, dropdowns here
end

return GUI
