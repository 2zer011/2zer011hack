-- Core loop skeleton
local Core = {}
local Target = require(script.TargetSelector)
local AI = require(script.AICombo)

function Core.Start(Config)
    print("Core started")
    -- main loop (SAFE placeholder)
end

return Core
