-- AI combo decision skeleton
local AI = {}

function AI.Run(enemy, Config)
    -- choose combo based on HP / fruit (placeholder)
end

return AI
